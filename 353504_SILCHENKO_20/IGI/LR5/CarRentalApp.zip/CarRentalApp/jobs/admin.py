from django.contrib import admin

from jobs.models import Job

admin.site.register(Job)
