from django.contrib import admin

from reviews.models import Review

admin.site.register(Review)