from django.contrib import admin
from .models import *

admin.site.register(AboutCompany)
admin.site.register(Promotional)
admin.site.register(FAQ)
admin.site.register(News)